=== Smart Dealer ===
Contributors: smartdealer
Donate link: http://smartdealership.com.br
Tags: smartdealer, sds, smart dealer
Requires at least: 1.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin de integra��o do Smart Dealer com o Wordpress.

== Description ==

Coloque seu estoque online e em tempo real com o plugin Smart Dealer de integra��o via webservices para Wordpress.

== Installation ==

1. Instale e ative o plugin
2. Configure o usu�rio de integra��o
3. Crie as p�ginas no Wordpress
4. Adicione as flags de conte�do
5. Configure no plugin as p�ginas de destino (p�gina da oferta/detalhes do ve�culo)

== Frequently Asked Questions ==

= Como consigo meu login e senha de acesso? =

Entre em contato com a Smart Dealer pelo e-mail, contato@smartdealership.com.br.

= Aonde minhas leads recebidas s�o registadas? =

S�o registradas no Smart Dealer

== Screenshots ==

1. Tela de configura��o 
`/screens/screenshot-1.jpg`

2. Exemplo de site com plugin instalado
`/screens/screenshot-2.jpg`

== Changelog ==

= 1.1 =
* Vers�o est�vel compat�vel com wordpress 4.0

= 1.0 =
* Primeira vers�o (beta)

== Upgrade Notice ==

= 1.1 =
Carregamento autom�tico de dados por flags de conte�do, para f�cil instala��o.

= 1.0 =
Vers�o beta (testes) com listagem simples de ve�culos

== Arbitrary section ==

Sem coment�rios.

== A brief Markdown Example ==

Sem coment�rios.